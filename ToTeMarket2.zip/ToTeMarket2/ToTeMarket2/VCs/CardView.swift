//
//  CardView.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import SwiftUI

struct CardView: View {
    var item: MenuItem
    @State var stepperValue: Int = 5000
    @EnvironmentObject var order: Order
    var white = Color.white.opacity(0.85)
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(white)
                
                Spacer()
            }
    }
    var body: some View {
NavigationLink(destination: ItemDetailVC(item: item)) {
        VStack(spacing: 35){
          
            Image(item.thumbnailImage)
                .resizable()
                .frame(width: 350, height: 220)
                .scaledToFill()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(20)
            
            HStack{
                
                VStack(alignment: .leading, spacing: 6) {
                    
                    Text(item.name)
                        .foregroundColor(white)
                    
                    Text(String("ريال \(item.price)"))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                
                Spacer(minLength: 0)
                
                Button(action: {
                    self.order.add(item: self.item)
                }) {
                    
                    Image(systemName: "plus")
                        .foregroundColor(.black)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                }
            }
            .padding(.horizontal)
        }
        
        .padding(.bottom)
        .background(
            
            LinearGradient(gradient: .init(colors: [Color.white.opacity(0.1),Color.black.opacity(0.35)]), startPoint: .top, endPoint: .bottom)
                .cornerRadius(25)
                .padding(.top,55))
             
          }
        .frame(width: 380, height: 330)
    }
}

