//
//  DoCardView.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import SwiftUI

struct DoCardView: View {
    var item: MenuItem
    @State var stepperValue: Int = 5000
    @EnvironmentObject var order: Order
    var white = Color.white.opacity(0.85)
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(white)
                
                Spacer()
            }
    }
    var body: some View {
   NavigationLink(destination: ItemDetailVC(item: item)) {
        VStack(spacing: 35){
            HStack{
                
                Image(item.thumbnailImage)
                    .resizable()
                    .scaledToFill()
                    .clipShape(Circle())
                    .frame(width: 160, height: 160)
                    .overlay(Circle().stroke(Color.white, lineWidth: 2))
                    .shadow(radius: 2)
                
                VStack(alignment: .leading, spacing: 6) {
                    
                    Text(item.name)
                        .fontWeight(.bold)
                        .foregroundColor(.white)

                    Text("افضل الاسعار")
                        .foregroundColor(white)
                    
                    Text(String("ريال \(item.price)"))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                
                Spacer(minLength: 5)
            }
            .padding([.vertical,.trailing])
            .background(
            
                LinearGradient(gradient: .init(colors: [Color("g1"),Color("g2")]), startPoint: .top, endPoint: .bottom)
                    .cornerRadius(25)
                    .padding(.vertical,25)
                    .padding(.leading,30)
            )
            .padding(.horizontal)
     
            
                    }
              }
        }
    
}

            
            

