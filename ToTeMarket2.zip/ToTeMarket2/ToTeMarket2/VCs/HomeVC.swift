//
//  HomeVC.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import SwiftUI
import Firebase

struct HomeVC: View {
  
    let menu = Bundle.main.decode([MenuSection].self, from: "menu.json")

    
    var white = Color.white.opacity(0.85)
    
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(white)
                
                Spacer()
            }
    }
    
    var body: some View {
       
        VStack{
            
            ZStack{
                
                HStack{
                    
                    Button(action: {}) {
                        
                        Image(systemName: "rectangle.grid.2x2")
                            .font(.title2)
                            .foregroundColor(white)
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        try! Auth.auth().signOut()
                        UserDefaults.standard.set(false, forKey: "status")
                        NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
                    }) {
                        
                        Image("out")
                            .resizable()
                            .frame(width: 45, height: 45)
                    }
                }
                
                Text("المطعم الشرقي")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
            .padding([.horizontal,.bottom])
            .padding(.top,10)
            
            
              Header(title: "العروض اليومية")
              .padding()
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack{
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 25){
                            ForEach(menu) { section in
                           
                                    ForEach(section.items) { item in
                                        UpCardView(item: item)
                                    
                                }
                            }
                        }
                    }
                    
                    
              
                    
                    Header(title: "الاكثر طلب")
                    .padding()
               
                    ScrollView(.horizontal, showsIndicators: false) {
                        
                        HStack(spacing: 25){
                            ForEach(menu) { section in
                            
                                    ForEach(section.items) { item in
                                        CardView(item: item)
                                    
                                }
                            }
                        }
                        .padding()
                        .padding(.horizontal,4)
                    }
                    
                    Header(title: "طلبات الافراد")
                    .padding()
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 25){
                            ForEach(menu) { section in
                           
                                    ForEach(section.items) { item in
                                        DoCardView(item: item)
                                    
                                }
                            }
                        }
                    }
                 
                      }
                .padding(.bottom,100)
            }
        }.navigationBarHidden(true)
    }
}

