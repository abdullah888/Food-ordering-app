//
//  DeliveryVC.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 25/01/1443 AH.
//

import SwiftUI

struct DeliveryVC: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DeliveryVC_Previews: PreviewProvider {
    static var previews: some View {
        DeliveryVC()
    }
}
