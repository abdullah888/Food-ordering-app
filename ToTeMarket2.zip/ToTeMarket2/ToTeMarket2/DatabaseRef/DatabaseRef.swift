//
//  DatabaseRef.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//


import Foundation
import Firebase
import FirebaseDatabase

var ref: DatabaseReference! = Database.database().reference()

var ORDERS_REF = ref.child("orders")
