//
//  Myorder.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import Foundation


struct Myorder: Identifiable {
    
    var id = UUID()
    var total: Double
    var numberOfItems: Int
    var date: Int
    var items: [Item]
    
}
