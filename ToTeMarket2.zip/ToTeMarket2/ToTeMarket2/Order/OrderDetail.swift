//
//  OrderDetail.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import SwiftUI

struct OrderDetail: View {
    
    let order: Myorder
    
    
    var body: some View {
        
        List {
            ForEach(order.items) { item in
                
                HStack {
                    Image("\(item.name.lowercased().withReplacedCharacters(" ", by: "-"))-thumb")
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.gray, lineWidth: 2))
                    
                    VStack(alignment: .leading) {
                        HStack {
                            Text(item.name)
                                .font(.headline)
                            Text(" x\(item.quantity)")
                        }
                        
                    }
                    Spacer()
                    Text(String("$\(item.price)"))
                    
                }
                
            }
        }
        
    }
    
}


