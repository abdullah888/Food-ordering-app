//
//  AllOrderVC.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 19/01/1443 AH.
//

import SwiftUI

struct AllOrderVC: View {
    @State private var show = false
    @EnvironmentObject var order: Order
    var white = Color.white.opacity(0.85)
    init() {
       UITableView.appearance().separatorStyle = .none
        UITableViewCell.appearance().backgroundColor =  UIColor(Color("bg"))
       UITableView.appearance().backgroundColor = UIColor(Color("bg"))
    }
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(white)
                
                Spacer()
            }
    }
    var body: some View {
       
            VStack{
                ZStack{
                    
                    HStack{
                        Text("الطلبات")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        Spacer()
                        
                        NavigationLink(destination: CheckoutVC()) {
                            Text("مشاهدة الفاتورة")
                        }
                    }.disabled(order.items.isEmpty)
                    
                    Image("iwaiter")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .foregroundColor(white)
                    
                        
                        
                }
                .padding([.horizontal,.bottom])
                .padding(.top,10)
                List{
                    
                        ForEach(order.items) { item in
                           
                            HStack{
                                
                                Image("\(item.name.lowercased().withReplacedCharacters(" ", by: "-"))-thumb")
                                    .resizable()
                                    .scaledToFill()
                                    .clipShape(Circle())
                                    .frame(width: 160, height: 160)
                                    .overlay(Circle().stroke(Color.white, lineWidth: 2))
                                    .shadow(radius: 2)
                                
                                VStack(alignment: .leading, spacing: 6) {
                                    
                                    Text(item.name)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)

                                    Text(" عدد \(item.quantity)")
                                        .foregroundColor(white)
                                    
                                    Text("\(item.price) ريال")
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                    
                                }
                                
                                
                                Spacer(minLength: 5)
                            }
                            .padding([.vertical,.trailing])
                         
                            .background(
                            
                                LinearGradient(gradient: .init(colors: [Color("g1"),Color("g2")]), startPoint: .top, endPoint: .bottom)
                                    .cornerRadius(25)
                                    .padding(.vertical,25)
                                    .padding(.leading,30)
                            )
                            .padding(.horizontal)
                          
                            
                        }
                        
                        .onDelete(perform: deleteItems)
                        .listRowBackground(Color("bg").ignoresSafeArea())
                        
                }
            }.navigationBarHidden(true)
            .accentColor(.white)
        }
    
    func deleteItems(at offsets: IndexSet) {
        order.items.remove(atOffsets: offsets)
    }
}

struct AllOrderVC_Previews: PreviewProvider {
    static let order = Order()
    static var previews: some View {
        AllOrderVC().environmentObject(order)
    }
}
