//
//  CheckoutVC.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 19/01/1443 AH.
//
import SDWebImageSwiftUI
import SwiftUI
import Firebase
import CoreLocation

struct CheckoutVC: View {
    @StateObject var xLocationModel = LocationModel()
    @Environment(\.presentationMode) var presentationMode
    var white = Color.white.opacity(0.85)
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(white)
                
                Spacer()
            }
    }
    init() {
       UITableView.appearance().separatorStyle = .none
        UITableViewCell.appearance().backgroundColor =  UIColor(Color("bg"))
       UITableView.appearance().backgroundColor = UIColor(Color("bg"))
    }
    
    @EnvironmentObject var order: Order
    @State var ordered = false
    static let tipAmounts = [10, 15, 20, 25, 0]
    @State private var paymentType = 0
    @State private var addLoyaltyDetails = false
    @State private var loyaltyNumber = ""
    @State private var tipAmount = 1
    @State private var showingPaymentAlert = false
    var totalPrice: Double {
        let total = Double(order.total)
        let tipValue = total / 100 * Double(Self.tipAmounts[tipAmount])
        return total + tipValue
    }
    var body: some View {
        ZStack{
            Color("bg") .edgesIgnoringSafeArea(.all)
            VStack{
                
        Header(title: "الفاتورة")
        .padding()
        Form {
            Section {
                HStack{
                    Text("عند الاستلام")
                        .font(.headline)
                      
                    Spacer()
                    Text("طريقة الدفع ")
                        .font(.title)
                       
                    
                }
                .foregroundColor(white)
                .listRowBackground(Color("bg").ignoresSafeArea())
            }
            Section {
                HStack{
                    Spacer()
                    Text("مراجعة الطلب")
                        .font(.title)
                        
                }
                .foregroundColor(white)
                .listRowBackground(Color("bg").ignoresSafeArea())
            }.onTapGesture {
                presentationMode.wrappedValue.dismiss()
            }
            
            Section {
                HStack{
                    
                    Text(xLocationModel.userAddress)
                           
                    Spacer()
                Text(xLocationModel.userLocation == nil ? "انتظر..." : "العنوان")
                    .font(.title)
                       
                }
                .foregroundColor(white)
           
            }.listRowBackground(Color("bg").ignoresSafeArea())
            
            Section{
                HStack{
                  
                    Text("%15")
                        .font(.headline)
                       
                       
                    Spacer()
                    Text("الضريبة المضافة")
                        .font(.title)
                        
                   
                    
                }
                .foregroundColor(white)
            }.listRowBackground(Color("bg").ignoresSafeArea())
            
            Section{
                HStack{
                    
                  
                    Text("السعر كامل : \(totalPrice, specifier: "%.2f") ريال")
                    .font(.largeTitle)
                    .foregroundColor(white)
                   
                    
                }
               
            }.listRowBackground(Color("bg").ignoresSafeArea())
            
            Section{
                HStack{
                    
                    
                    Text("تاكيد الطلب")
                    .font(.headline)
                    .foregroundColor(.green)
                    Spacer()
                    
                }
               
            }.listRowBackground(Color("bg").ignoresSafeArea())
            .onTapGesture {
                self.showingPaymentAlert.toggle()
                // Add order to database
                guard let currentuid = Auth.auth().currentUser?.uid else { return }
                //حاول تضيف العنوان
             
                let total = totalPrice
                let date = Int(NSDate().timeIntervalSince1970)
                var quant: Int = 0
                for item in order.items {
                    quant += item.quantity
                }
                let numberOfItems = quant
                let values = ["total": total,
                          "date": date,
                         
                          "numberOfItems": numberOfItems
                ] as [String : Any]
               
                let orderid = ORDERS_REF.child(currentuid).childByAutoId()
                orderid.setValue(values)
                for item in order.items {
                    let name = item.name
                    let price = item.price
                    let quantity = item.quantity
                    let val = [
                        "name": name,
                        "price": price,
                        
                        "quantity": quantity
                    ] as [String : Any]
                    orderid.child("items").childByAutoId().setValue(val)
                    //add here
                
                        self.updateOrderdetails()
                    
                 
                }
                
            }
        }
        .alert(isPresented: $showingPaymentAlert) {
            Alert(title: Text("تم تاكيد الطلب"), message: Text("الحساب كامل SR\(totalPrice, specifier: "%.2f")  بالهناء والعافية"), dismissButton: .default(Text("انتهى"), action: { order.reset()
                presentationMode.wrappedValue.dismiss()
            }))
                }
    
           }
            if xLocationModel.noLocation{
                
                Text("من الاعدادات قم بالسماح للوصول الى الموقع")
                    .foregroundColor(.black)
                    .frame(width: UIScreen.main.bounds.width - 100, height: 120)
                    .background(Color.white)
                    .cornerRadius(10)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color.black.opacity(0.3).ignoresSafeArea())
            }
            
        }.navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .onAppear(perform: {
            
            // calling location delegate....
            xLocationModel.locationManager.delegate = xLocationModel
        })
    }
    func updateOrderdetails(){
        
           let db = Firestore.firestore()
   
           // creating dict of food details...
   
           if ordered{
   
               ordered = false
   
               db.collection("UsersOrder").document(Auth.auth().currentUser!.uid).delete { (err) in
   
                   if err != nil{
                       self.ordered = true
                   }
               }
   
               return
           }
   
           var details : [[String: Any]] = []
   
        order.items.forEach { (orderr) in
            if orderr.quantity > 0 {
                details.append([
                 "Order_Name" : orderr.name,
                 "Order_price": orderr.price,
                 "Order_quantity": orderr.quantity,
                 "Order_Image":orderr.photoCredit,
                 "Order_totalPrice":totalPrice
    
    
    
                ])
            }
         
           }
   
           ordered = true
   
           db.collection("UsersOrder").document(Auth.auth().currentUser!.uid).setData([
   
               "ordered_food": details,
            "location": GeoPoint(latitude: xLocationModel.userLocation.coordinate.latitude, longitude: xLocationModel.userLocation.coordinate.longitude)
   
           ]) { (err) in
   
               if err != nil{
                   self.ordered = false
                   return
               }
               print("success")
           }
       }
   
       
}

struct CheckoutVC_Previews: PreviewProvider {
    static let order = Order()
    static var previews: some View {
        CheckoutVC().environmentObject(order)
    }
}


