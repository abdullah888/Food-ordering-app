//
//  Login.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import SwiftUI
import Firebase



struct Login : View {
    
    @State var color = Color.black.opacity(0.7)
    @State var email = ""
    @State var pass = ""
    @State var visible = false
    @Binding var show : Bool
    @State var alert = false
    @State var error = ""
    var white = Color.white.opacity(0.85)
    var body: some View{
        ZStack{
            Color("bg").edgesIgnoringSafeArea(.all)
        ZStack{
            
            ZStack(alignment: .topTrailing) {
                
                GeometryReader{_ in
                    
                    VStack{
                        HStack{
                            VStack{
                                Image("Logo")
                                    .resizable()
                                    .frame(width: 150, height: 150)
                                Text("المطعم الشرقي")
                                    .bold()
                                    .font(.largeTitle)
                                    .foregroundColor(white)
                           
                            }
                            .padding()
                            
                            Spacer()
                        }
                       
                       
                        
                        TextField("Email", text: self.$email)
                            .foregroundColor(white)
                            .autocapitalization(.none)
                            .padding()
                        Divider()
                         .frame(height: 1)
                         .padding(.horizontal, 30)
                         .background(white)
                        .padding(.top, 10)
                        
                        HStack(spacing: 15){
                            
                            VStack{
                                
                                if self.visible{
                                    
                                    TextField("Password", text: self.$pass)
                                        .foregroundColor(white)
                                        .autocapitalization(.none)
                                }
                                else{
                                    
                                    SecureField("Password", text: self.$pass)
                                        .foregroundColor(white)
                                        .autocapitalization(.none)
                                }
                            }
                            
                            Button(action: {
                                
                                self.visible.toggle()
                                
                            }) {
                                
                                Image(systemName: self.visible ? "eye.slash.fill" : "eye.fill")
                                    .foregroundColor(self.color)
                            }
                            
                        }
                        .padding()
                        Divider()
                         .frame(height: 1)
                         .padding(.horizontal, 30)
                         .background(white)
                        .padding(.top, 10)
                        
                        HStack{
                            
                            Spacer()
                            
                            Button(action: {
                                
                                self.reset()
                                
                            }) {
                                
                                Text("هل نسيت الرقم السري ؟")
                                    .fontWeight(.bold)
                                    .foregroundColor(white)
                            }
                        }
                        .padding(.top, 20)
                        
                        Button(action: {
                            
                            self.verify()
                            
                        }) {
                            
                            Text("تسجيل دخول")
                                .bold()
                                .font(.title)
                                .foregroundColor(Color("bg"))
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }
                        .background(white)
                        .cornerRadius(10)
                        .padding(.top, 25)
                        
                    }
                    .padding(.horizontal, 25)
                }
                
                Button(action: {
                    
                    self.show.toggle()
                    
                }) {
                    
                    Text("تسجيل جديد")
                        .fontWeight(.bold)
                        .foregroundColor(white)
                }
                .padding()
            }
            
            if self.alert{
                
                ErrorView(alert: self.$alert, error: self.$error)
               }
            }
        }
    }
    
    func verify(){
        
        if self.email != "" && self.pass != ""{
            
            Auth.auth().signIn(withEmail: self.email, password: self.pass) { (res, err) in
                
                if err != nil{
                    
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                
                print("success")
                UserDefaults.standard.set(true, forKey: "status")
                NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
            }
        }
        else{
            
            self.error = "Please fill all the contents properly"
            self.alert.toggle()
        }
    }
    
    func reset(){
        
        if self.email != ""{
            
            Auth.auth().sendPasswordReset(withEmail: self.email) { (err) in
                
                if err != nil{
                    
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                
                self.error = "RESET"
                self.alert.toggle()
            }
        }
        else{
            
            self.error = "Email Id is empty"
            self.alert.toggle()
        }
    }
}
