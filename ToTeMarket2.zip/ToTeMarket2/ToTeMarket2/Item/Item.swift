//
//  Item.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import Foundation
import CoreLocation


struct Item: Identifiable {
    
    var id = UUID().uuidString
    var name: String
    var price: Int
    var quantity: Int
   
}
