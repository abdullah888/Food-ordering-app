//
//  ItemDetailVC.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 20/01/1443 AH.
//

import SwiftUI

struct ItemDetailVC: View {
    let menu = Bundle.main.decode([MenuSection].self, from: "menu.json")
    @State var count = 0
    @State var height = UIScreen.main.bounds.height
    var item: MenuItem
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var order: Order
    var white = Color.white.opacity(0.85)
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(white)
                
                Spacer()
            }
    }
  
    
    var body: some View{
        
        ZStack{
            
            Color("bg").edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0){
                
                Image(item.mainImage)
                    
                    .resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width, height: 400)
                    .background(Color.black)
                    .edgesIgnoringSafeArea(.all)
                
                ZStack(alignment: .topTrailing) {
                    
                    if self.height > 750 {
                        
                        VStack{
                          //
                            
                            VStack{
                                VStack(alignment: .leading){
                                    Text(item.name)
                                        .font(.title)
                                        .fontWeight(.bold)
                                    
                                    Text(String("\(item.price)ريال"))
                                        .foregroundColor(.secondary)
                                }
                                .padding(.top)
                                .frame(maxWidth: .infinity, alignment: .leading)
                              
                                Text("بالهناء والعافية")
                                    .font(.title)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .padding()
                                Text(item.description)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .padding()
                              
                            }
                            .padding()
                            .background(Color(.systemBackground))
                            .cornerRadius(30)

                        }
                        .padding(.bottom, 40)
                        .padding(.horizontal,20)
                        .background(CustomShape().fill(Color.white))
                        .clipShape(Corners())
                    }
                        
                    VStack(spacing : 15){
                        
                        Button(action: {
                        
                            self.count += 1
                            self.order.add(item: item)
                            
                        }) {
                            
                            Image(systemName: "plus.circle")
                                .foregroundColor(Color("bg"))
                                .font(.title)
                        }
                        
                        Text("\(self.count)")
                        .foregroundColor(white)
                        .padding(10)
                        .background(Color.black)
                        .clipShape(Circle())
                        
                        Button(action: {
                            
                            if self.count != 0{
                                self.order.remove(item: item)
                                self.count -= 1
                            }
                            
                        }) {
                            
                            Image(systemName: "minus.circle")
                                .foregroundColor(Color("bg"))
                                .font(.title)
                        }
                    }
                    .padding()
                    .background(white)
                    .cornerRadius(10)
                    .shadow(radius: 4)
                    .padding(.trailing,25)
                    .offset(y: -55)
                }
                .zIndex(40)
                .offset(y: -40)
                .padding(.bottom, -40)
                
                HStack{
                    
                    VStack(alignment: .leading, spacing: 15) {
                        
                        Text("عدد الوجبات")
                            .fontWeight(.bold)
                        
                        HStack(spacing : 18){
                            
                            VStack(spacing: 8){
                                
                                Text("\(self.count)")
                                    .fontWeight(.bold)
                                    .padding()
                               
                            }
                          
                        }
                    }
                    .foregroundColor(white)
                    .padding(.leading, 20)
                    
                    Spacer(minLength: 0)
                    
                    Button(action: {
                        
                        
                    }) {
                        
                        VStack{
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }, label: {
                               Text("انتهى")
                                    .fontWeight(.bold)
                            })
                        }
                        .foregroundColor(white)
                        .padding(.horizontal, 25)
                        .padding(.vertical, 25)
                        .background(Color("bg"))
                        .cornerRadius(15)
                        .shadow(radius: 8)
                    }
                    .padding(.trailing, 25)
                    .offset(y: -55)
                }
                .zIndex(40)
                .padding(.bottom, 10)
                
            }
            .edgesIgnoringSafeArea(.top)
            .animation(.default)
        }.navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

struct ItemDetailVC_Previews: PreviewProvider {
    static let order = Order()
    static var previews: some View {
        NavigationView {
            ItemDetailVC(item: MenuItem.example).environmentObject(order)
        }
    }
}



struct CustomShape : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        return Path{path in

            path.move(to: CGPoint(x: 0, y: 0))
            path.addLine(to: CGPoint(x: rect.width, y: 0))
            path.addLine(to: CGPoint(x: rect.width, y: rect.height))
            path.addLine(to: CGPoint(x: 0, y: rect.height - 40))
            
        }
    }
}

struct Corners : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.topLeft,.topRight], cornerRadii: CGSize(width: 35, height: 35))
        
        return Path(path.cgPath)
    }
}

class Host: UIHostingController<ContentView> {
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        
        return .lightContent
    }
    
    override var prefersHomeIndicatorAutoHidden: Bool{
        
        return true
    }
}
