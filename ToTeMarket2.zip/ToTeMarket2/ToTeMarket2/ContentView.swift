//
//  ContentView.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//

import SwiftUI
import Firebase

struct ContentView: View {
    var animation: Namespace.ID
    let menu = Bundle.main.decode([MenuSection].self, from: "menu.json")
    
    
    var body: some View {
       HomeVC()
    }
    
}


//
//struct SeveView : View {
//
//
//
//    var body: some View {
//
//        var animation: Namespace.ID
//        let menu = Bundle.main.decode([MenuSection].self, from: "menu.json")
//
//
//        var body: some View {
//            NavigationView {
//                List {
//                    ForEach(menu) { section in
//                        Section(header: Text(section.name)) {
//                            ForEach(section.items) { item in
//                                CardView(item: item)
//                            }
//                        }
//                    }
//                }
//                .navigationBarTitle("Menu", displayMode: .inline)
//                .listStyle(GroupedListStyle())
//                .navigationBarItems(trailing: Button(action: {
//
//                    try! Auth.auth().signOut()
//                    UserDefaults.standard.set(false, forKey: "status")
//                    NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
//
//                }) {
//                    Text("Log out")
//                })
//
//            }
//        }
//
//
//
//
//
//    }
//}
//
