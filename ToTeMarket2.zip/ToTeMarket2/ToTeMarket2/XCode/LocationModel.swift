//
//  LocationModel.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 24/01/1443 AH.
//


import SwiftUI
import CoreLocation
import Firebase

// Fetching User Location....
class LocationModel: NSObject,ObservableObject,CLLocationManagerDelegate{
    
    @Published var locationManager = CLLocationManager()
    // Location Details....
    @Published var userLocation : CLLocation!
    @Published var userAddress = ""
    @Published var noLocation = false
    
    //userorderlocation
    @Published var ordered = false
    @Published var order : [Order] = []
   // @EnvironmentObject var order: Order
   
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
    
        // checking Location Access....
        
        switch manager.authorizationStatus {
        case .authorizedWhenInUse:
            print("authorized")
            self.noLocation = false
            manager.requestLocation()
        case .denied:
            print("denied")
            self.noLocation = true
        default:
            print("unknown")
            self.noLocation = false
            // Direct Call
            locationManager.requestWhenInUseAuthorization()
            // Modifying Info.plist...
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
        print(error.localizedDescription)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // reading User Location And Extracting Details....
        
        self.userLocation = locations.last
        self.extractLocation()
    }
    
    func extractLocation(){
        
        CLGeocoder().reverseGeocodeLocation(self.userLocation) { (res, err) in
            
            guard let safeData = res else{return}
            
            var address = ""
            
            // getting area and locatlity name....
            
            address += safeData.first?.name ?? ""
            address += ", "
            address += safeData.first?.locality ?? ""
            
            self.userAddress = address
        }
    }
  
//    func updateOrderdetails(){
//
//        let db = Firestore.firestore()
//
//        // creating dict of food details...
//
//        if ordered{
//
//            ordered = false
//
//            db.collection("Users").document(Auth.auth().currentUser!.uid).delete { (err) in
//
//                if err != nil{
//                    self.ordered = true
//                }
//            }
//
//            return
//        }
//
//        var details : [[String: Any]] = []
//
//        order.forEach { (orderr) in
//
//            details.append([
//                "Order_Name" : orderr.items
//
//
//
//            ])
//        }
//
//        ordered = true
//
//        db.collection("Users").document(Auth.auth().currentUser!.uid).setData([
//
//            "ordered_food": details,
//            "location": GeoPoint(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
//
//        ]) { (err) in
//
//            if err != nil{
//                self.ordered = false
//                return
//            }
//            print("success")
//        }
//    }
    
    
    
    
    
}



