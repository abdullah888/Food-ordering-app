//
//  Action.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 15/01/1443 AH.
//

import SwiftUI

struct Action: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Action_Previews: PreviewProvider {
    static var previews: some View {
        Action()
    }
}
