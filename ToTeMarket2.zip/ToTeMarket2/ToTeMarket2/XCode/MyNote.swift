//
//  MyNote.swift
//  ToTeMarket2
//
//  Created by abdullah FH  on 13/01/1443 AH.
//




// اول شي سكنت دلقت لها اضافات



/*    var order = Order()
 
 
 
 let contentView = AppView()
     .environmentObject(order)

 // Use a UIHostingController as window root view controller.
 if let windowScene = scene as? UIWindowScene {
     let window = UIWindow(windowScene: windowScene)
     window.rootViewController = UIHostingController(rootView: contentView)
     self.window = window
     window.makeKeyAndVisible()
 }

 
 
 */
